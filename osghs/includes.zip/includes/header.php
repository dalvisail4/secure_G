  <header class="header-section">
    
    <div class="header-bottom">
      <a href="index.php" class="site-logo">
        <h4 style="color:BLACK"><strong>SECURE-G</strong></h4>
      </a>
    
      <div class="container">
        <ul class="main-menu">
          <li><a href="home.php" >Home</a></li>
          <li><a href="index.php">Hiring Form</a></li>
          <li><a href="search-request.php">Request Status</a>
                     </li>
          <li><a href="admin/login.php">Admin</a></li>
        </ul>
      </div>
    </div>
  </header>